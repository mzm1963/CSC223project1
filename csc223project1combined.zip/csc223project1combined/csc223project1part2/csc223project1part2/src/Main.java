import java.util.Scanner;
//Matthew Marcantonio CSC223 Assignment 1 part 2
public class Main {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter the number you'd like to find the square root of");
        float n = scnr.nextFloat();
        System.out.println("Please enter a guess for the numbers square root");
        float x = scnr.nextFloat();
        float temp = ((x + (n/x)) / 2);
        float answer = temp + 1;


        while(answer - temp > 1e-8){

            answer = temp;

            temp = ((temp + (n/temp)) / 2);

            System.out.println(answer);

        }


System.out.println("The square root of " + n + " is " + answer);






    }
}