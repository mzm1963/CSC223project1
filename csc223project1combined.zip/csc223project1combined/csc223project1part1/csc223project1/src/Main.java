import java.util.Scanner;

//Matthew Marcantonio CSC223 project 1 part 1
public class Main {

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Please enter a positive integer");
        int x = scnr.nextInt();
        System.out.println("Please enter another positive integer");
        int y = scnr.nextInt();
        int answer = 0;
        while(x >= 1){
            System.out.printf("%10s", x + " " + y + "\n");
            if (x%2 == 1){
                answer += y;
            }
            y = y * 2;
            x = x/2;

        }
        System.out.printf("%10s", "Your answer is: " + answer);
    }


}